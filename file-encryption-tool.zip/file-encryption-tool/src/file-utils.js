import { existsSync } from 'node:fs';
import { dirname } from 'node:path';

export function ensureDir(path) {
  const dir = dirname(path);
  if (!existsSync(dir)) {
    throw new Error(`Directory not found: ${dir}`);
  }
}

export function checkFileExists(path) {
  if (!existsSync(path)) {
    throw new Error(`File not found: ${path}`);
  }
}
