import { encryptFile, decryptFile } from './crypto.js';
import { ensureDir, checkFileExists } from './file-utils.js';
import process from 'node:process';

const [, , mode, src, dest] = process.argv;

if (!mode || !src || !dest) {
  console.error('Usage:');
  console.error('  node src/cli.js encrypt test/sample.txt test/sample.enc');
  console.error('  node src/cli.js decrypt test/sample.enc test/sample_decrypted.txt');
  process.exit(1);
}

ensureDir(dest);

async function run() {
  try {
    if (mode === 'encrypt') {
      checkFileExists(src);
      await encryptFile(src, dest);
      console.log(`✅ File Encrypted: ${src} → ${dest}`);
    } else if (mode === 'decrypt') {
      checkFileExists(src);
      await decryptFile(src, dest);
      console.log(`✅ File Decrypted: ${src} → ${dest}`);
    } else {
      console.error('❌ Mode must be "encrypt" or "decrypt"');
      process.exit(1);
    }
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

run();
