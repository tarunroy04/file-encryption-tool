import crypto from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const algorithm = 'aes-256-cbc';
const KEY = Buffer.from('12345678901234567890123456789012', 'utf8'); // exactly 32 chars

export async function encryptFile(inPath, outPath) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(algorithm, KEY, iv);

  const input = readFileSync(inPath);
  const encrypted = Buffer.concat([cipher.update(input), cipher.final()]);

  // Store: [16 bytes IV] + [encrypted data]
  const output = Buffer.concat([iv, encrypted]);
  writeFileSync(outPath, output);
}

export async function decryptFile(inPath, outPath) {
  const input = readFileSync(inPath);

  // First 16 bytes = IV, rest = encrypted data
  const iv = input.subarray(0, 16);
  const encryptedData = input.subarray(16);

  const decipher = crypto.createDecipheriv(algorithm, KEY, iv);
  const decrypted = Buffer.concat([decipher.update(encryptedData), decipher.final()]);

  writeFileSync(outPath, decrypted);
}
